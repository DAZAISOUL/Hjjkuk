package com.zyon.arithiusbedrock

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import com.zyon.arithiusbedrock.overlay.OverlayService

class MainActivity : Activity() {
    private val maroon = Color.rgb(105, 20, 45)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(248, 246, 247))
        }
        val title = TextView(this).apply {
            text = "ARITHIUS BEDROCK"
            textSize = 24f
            setTextColor(maroon)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Companion overlay · Android · No Root\nMinecraft Bedrock 26.51 target"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        val permission = Button(this).apply {
            text = "Grant overlay permission"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val start = Button(this).apply {
            text = "Start floating menu"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        val stop = Button(this).apply {
            text = "Stop floating menu"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }
}
