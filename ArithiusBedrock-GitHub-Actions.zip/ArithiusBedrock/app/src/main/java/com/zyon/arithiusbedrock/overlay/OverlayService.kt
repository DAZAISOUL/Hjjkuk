package com.zyon.arithiusbedrock.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.Context
import android.content.SharedPreferences

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("module_flags", Context.MODE_PRIVATE)
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(105, 20, 45))
        }
        val header = TextView(this).apply {
            text = "ARITHIUS  ·  BEDROCK"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 4, 4, 10)
        }
        container.addView(header)
        addToggle(container, "X-Ray pack helper", "xray")
        addToggle(container, "ESP pack helper", "esp")
        addToggle(container, "Movement pack helper", "movement")
        val note = TextView(this).apply {
            text = "Toggles save preferences only. They do not modify game memory."
            setTextColor(Color.LTGRAY)
            textSize = 10f
            setPadding(4, 10, 4, 0)
        }
        container.addView(note)

        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 140 }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(container, params)
                    true
                }
                else -> true
            }
        }
        panel = container
        windowManager.addView(container, params)
    }

    private fun addToggle(parent: LinearLayout, label: String, key: String) {
        val enabled = prefs.getBoolean(key, false)
        val item = TextView(this).apply {
            text = "$label: ${if (enabled) "ON" else "OFF"}"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(6, 9, 6, 9)
            setOnClickListener {
                val next = !prefs.getBoolean(key, false)
                prefs.edit().putBoolean(key, next).apply()
                text = "$label: ${if (next) "ON" else "OFF"}"
                Toast.makeText(this@OverlayService, "Saved: $label", Toast.LENGTH_SHORT).show()
            }
        }
        parent.addView(item)
    }

    override fun onDestroy() {
        panel?.let { windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
