# Arithius Bedrock — Android companion scaffold

Target: Android, standalone APK, no root. Minecraft Bedrock 26.51 is the intended
compatibility target; this scaffold has not been tested against that game build.

## What currently works
- Android Studio project structure.
- Overlay permission flow.
- Draggable floating panel.
- Three persistent preference toggles.
- Start/stop controls from the main activity.

## Important implementation boundary
The overlay is a separate Android process/app surface. Its toggles only save local
preferences; they do not read or write Minecraft memory, alter server state, or
provide ESP/X-Ray/KillAura/Reach/Fly cheats. Those features require supported
in-game extension APIs or a game-side mod/pack. This project is structured so
legitimate Bedrock resource/behavior pack integration can be added without
pretending an external overlay can modify the game.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK and grant "Display over other apps".
5. Tap "Start floating menu".

Compile SDK 35 and Android Gradle Plugin 8.7.3 are configured.


## Build APK with GitHub Actions (no computer build tools needed)

1. Create a new repository on GitHub.
2. Upload the **contents** of this project folder to the repository root (so
   `settings.gradle.kts`, `build.gradle.kts`, and `app/` are at the root).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow**, or push a commit
   to the `main` branch.
5. When the run finishes, open it and download the artifact named
   `ArithiusBedrock-debug-apk`.
6. Extract the artifact ZIP; it contains `app-debug.apk`.

The workflow uses Java 17, Gradle 8.9, Android SDK 35, and builds a debug APK.
A debug APK is suitable for local testing; it is not a Play Store release build.
