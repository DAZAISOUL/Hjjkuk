# Bedrock pack integration

Place separately authored Bedrock resource packs or behavior packs here while
developing. Import them into Minecraft using the game's supported pack import
workflow. Pack manifests and scripts should be validated against the exact
Bedrock 26.51 scripting/API version before release.
